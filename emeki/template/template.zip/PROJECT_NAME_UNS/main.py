"""The main script."""


def main():
    """The main function."""
    return 0


if __name__ == "__main__":
    main()
