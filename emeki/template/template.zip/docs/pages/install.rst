============
Installation
============

To install everything needed, run:

.. code-block:: bash

    pip install PROJECT_NAME
