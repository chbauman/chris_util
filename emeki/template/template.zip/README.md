# StoryTime
Diary-like GUI written in python.
